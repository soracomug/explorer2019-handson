import os
import requests
import json

def lambda_handler(event, context):
    # 環境変数取得
    line_token = os.environ['line_token']

    # 位置情報取得
    try:
        location_lat = context.client_context.custom["location"]["lat"]
        location_lon = context.client_context.custom["location"]["lon"]
    except:
        return 1

    # メッセージ生成
    message = "ボタンが押されました。\nおおよその位置：緯度:" + str(location_lat) + " 緯度:" + str(location_lon) + "\n https://www.google.com/maps/search/?api=1&query=" + str(location_lat) + "," + str(location_lon)

    # LINE Notify呼び出し
    data = push_line(line_token,message)
    response = json.loads(data)
    result = 0 if response['status'] == 200 else 1
    return result

def push_line(line_notify_token,message):
    line_notify_url   = 'https://notify-api.line.me/api/notify'
    payload = {'message': message }
    headers = {'Authorization': 'Bearer ' + line_notify_token}
    line_notify = requests.post(line_notify_url, data=payload, headers=headers).text
    return line_notify

